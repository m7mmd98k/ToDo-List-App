import { Component } from '@angular/core';
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { IDataModel } from './data.interface';
import { done, progress } from './data';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {

  constructor(private http: HttpClient){
    this.getTodos();
  }

  todos: IDataModel[] = [];
  progresses: IDataModel[] = progress;
  dones: IDataModel[] = done;
  
  url = 'https://dummyjson.com/todos';


  inputValue: string= '';
  isVisible: boolean = false;
  currentIndex: number = -1;

  
  getTodos() {
    this.http.get<{ todos: IDataModel[] }>(this.url).subscribe((data) => {
      console.info(data.todos);
      let switcher = data.todos;
      
      switcher.forEach(item=>{
        if (item.completed) {
          this.dones.push(item)
          
        } else {
          this.todos.push(item)
          
        }
      })
    });
  }

  addToList(inputValue: string) {
    this.todos.unshift({
      id: this.todos.length,
      todo: inputValue,
      completed: false,
      userId: 1,
    });
    this.inputValue = ''
  }

  removeFromList(Body: string) {
    let index = this.todos.findIndex( e => e.todo === Body);
    if (index !== -1) {
      this.todos.splice(index,1);
    }
  }
  onEditing = (index: number) => {
    this.isVisible = false;
    this.currentIndex = index;
    this.isVisible = !this.isVisible;
    
  }
  

  

  drop(event: CdkDragDrop<IDataModel[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
  }
}
